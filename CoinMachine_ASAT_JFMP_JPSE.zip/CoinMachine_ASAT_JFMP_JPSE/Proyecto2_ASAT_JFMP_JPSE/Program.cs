﻿using System;
using System.Globalization;
using static CASINO;

class CASINO
{
    //PARTICIPANTES: | SOFIA ASTURIAS - 1078123 | JORGE MUÑOZ - 1177523 | JOSÉ SOSA - 1057623 |
    static void Main(string[] args)
    {
        try
        {
            //NOMBRE COIN MACHINE
            string texto = "  | HAPPY CHANCE |  \n";
            for (int i = 0; i < texto.Length; i++)
            {
                ConsoleColor color;
                switch (i % 6)
                {
                    case 0:
                        color = ConsoleColor.Red;
                        break;
                    case 1:
                        color = ConsoleColor.Yellow;
                        break;
                    case 2:
                        color = ConsoleColor.Green;
                        break;
                    case 3:
                        color = ConsoleColor.Cyan;
                        break;
                    case 4:
                        color = ConsoleColor.Blue;
                        break;
                    case 5:
                        color = ConsoleColor.Magenta;
                        break;
                    default:
                        color = ConsoleColor.White;
                        break;
                }
                Console.ForegroundColor = color;
                Console.Write(texto[i]);
            }
            Console.ResetColor();

            //DATOS PERSONALES

            //NOMBRE COMPLETO
            Console.WriteLine("\n-Nombre del Usuario-");
            Console.Write("Primer nombre: ");
            string nombre = Console.ReadLine();
            Console.Write("Primer apellido: ");
            string apellido = Console.ReadLine();

            //NÚMERO DE IDENTIFICACIÓN
            Console.WriteLine("\n-Número de identificación (DPI)-");
            Console.Write("DPI No. ");
            string dpi = Console.ReadLine();
            int digitosDPI = dpi.ToString().Length;
            while (digitosDPI != 13)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("¡¡ERROR: El número de identificación no es valido!! ");
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine("Ingresa tu número de identificación (DPI) VALIDO");
                Console.Write("DPI No. ");
                dpi = Console.ReadLine();
                digitosDPI = dpi.ToString().Length;
            }
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine("¡Número de DPI Valido! :)");
            Console.ForegroundColor = ConsoleColor.White;

            //NACIONALIDAD
            Console.WriteLine("\n-Nacionalidad-");
            Console.Write("País de origen: ");
            string nacionalidad = Console.ReadLine();

            //FECHA DE NACIMIENTO
            Console.WriteLine("\n-Fecha de Nacimiento-");
            bool fechaValida = false;
            DateTime nacimientoUsuario = DateTime.MinValue;
            do
            {
                Console.WriteLine("Ingresa tu fecha de nacimiento en formato dia/mes/año : ");
                string fechaDeNacimiento = Console.ReadLine();

                if (DateTime.TryParseExact(fechaDeNacimiento, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out nacimientoUsuario))
                {
                    fechaValida = true;
                }
                else
                {
                    Console.WriteLine("\nLa fecha que ingresaste no es valida, recuerda usar '0' antes del número si tiene solo 1 digito y ' / ' entre cada número.");
                }

            } while (!fechaValida);
            DateTime fechaActual = DateTime.Today;
            int edad = fechaActual.Year - nacimientoUsuario.Year;
            if (nacimientoUsuario > fechaActual.AddYears(-edad))
            {
                edad--;
            }
            Console.WriteLine("Tienes " + edad + " años de edad.");
            if (edad >= 21)
            {
                Console.WriteLine("Sí puedes jugar :)");

                //SALIDA DE DATOS PERSONALES

                //APARIENCIA MONTO/////////////////////////
                Console.Clear();
                //NOMBRE COIN MACHINE
                string textoa = "  | HAPPY CHANCE |  \n";
                for (int i = 0; i < textoa.Length; i++)
                {
                    ConsoleColor color;
                    switch (i % 6)
                    {
                        case 0:
                            color = ConsoleColor.Red;
                            break;
                        case 1:
                            color = ConsoleColor.Yellow;
                            break;
                        case 2:
                            color = ConsoleColor.Green;
                            break;
                        case 3:
                            color = ConsoleColor.Cyan;
                            break;
                        case 4:
                            color = ConsoleColor.Blue;
                            break;
                        case 5:
                            color = ConsoleColor.Magenta;
                            break;
                        default:
                            color = ConsoleColor.White;
                            break;
                    }
                    Console.ForegroundColor = color;
                    Console.Write(texto[i]);
                }
                Console.ResetColor();
                Console.WriteLine("\n- APUESTA -");

                //MONTO APUESTA            
                string confirmaciontarjeta;
                Console.WriteLine("Ingrese la cantidad que desea apostar:");
                Console.Write("Q");
                double apuesta = Convert.ToDouble(Console.ReadLine());
                Console.WriteLine("\n¿Desea pagar con tarjeta de credito/debito? s = si, n = no ");
                Console.Write("-> ");
                confirmaciontarjeta = Console.ReadLine();
                if (confirmaciontarjeta == "s")
                {
                    //DIGITOS TARJETA
                    Console.WriteLine("\n-Ingrese los digitos de la tarjeta-");
                    Console.Write("No. ");
                    string tarjeta = Console.ReadLine();
                    int digitostarjeta = tarjeta.ToString().Length;
                    while (digitostarjeta != 16)
                    {
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("¡¡ERROR: El número de tarjeta no es valido!! ");
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.WriteLine("Ingresa tu número de tarjeta VALIDO");
                        Console.Write("No. ");
                        tarjeta = Console.ReadLine();
                        digitostarjeta = tarjeta.ToString().Length;
                    }

                    //TITULAR TARJETA
                    Console.WriteLine("\n-Titular de la tarjeta-");
                    Console.Write("Nombre y apellido: ");
                    string nombretarjeta = Console.ReadLine();

                    //FECHA EXPIRACIÓN TARJETA
                    Console.WriteLine("\n-Fecha de Expiración de Tarjeta-");
                    bool fechaValidaT = false;
                    DateTime expUsuarioT = DateTime.MinValue;
                    do
                    {
                        Console.Write("Ingresa tu fecha de expiración en formato dia/mes/año : ");
                        string fechaExpiraciónT = Console.ReadLine();

                        if (DateTime.TryParseExact(fechaExpiraciónT, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out expUsuarioT))
                        {
                            fechaValidaT = true;
                        }
                        else
                        {
                            Console.WriteLine("La fecha que ingresaste no es valida, recuerda usar '0' antes del número si tiene solo 1 digito y ' / ' entre cada número.");
                        }


                        bool expT = false;
                        do
                        {
                            DateTime fechaActualT = DateTime.Today;
                            if (expUsuarioT < fechaActualT)
                            {
                                Console.ForegroundColor = ConsoleColor.Red;
                                Console.WriteLine("La tarjeta está expirada, ingrese otra fecha:");
                                Console.ResetColor();
                                fechaExpiraciónT = Console.ReadLine();
                                if (DateTime.TryParseExact(fechaExpiraciónT, "dd/MM/yyyy", CultureInfo.InvariantCulture, DateTimeStyles.None, out expUsuarioT))
                                {
                                    fechaValidaT = true;
                                }
                                else
                                {
                                    Console.ForegroundColor = ConsoleColor.Red;
                                    Console.WriteLine("La fecha que ingresaste no es valida, recuerda usar '0' antes del número si tiene solo 1 digito y ' / ' entre cada número.");
                                    Console.ForegroundColor = ConsoleColor.White;
                                    fechaValidaT = false;
                                    break;
                                }
                            }
                            else
                            {
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine("Tarjeta verificada");
                                Console.ForegroundColor = ConsoleColor.White;
                                expT = true;
                            }
                        }
                        while (!expT);
                    } while (!fechaValida);
                }

                Console.WriteLine("\n¿ESTA SEGURO QUE DESEA CONTINUAR? s = si");
                Console.Write("-> ");
                string validacion = Console.ReadLine();

                if (validacion == "s")
                {
                    string menu = "";
                    while (!menu.Equals("2"))
                    {
                        switch (validacion)
                        {
                            case "s" or "S":
                                Console.Clear();
                                Random r = new Random();
                                int probabilidad = r.Next(1, 101);
                                int probabilidad2 = r.Next(1, 101);
                                int probabilidad3 = r.Next(1, 101);
                                int probabilidad4 = r.Next(1, 101);
                                int probabilidad5 = r.Next(1, 101);

                                //ICONOS CASINO                                
                                Console.WriteLine("- ICONOS -");
                                Console.ForegroundColor = ConsoleColor.Green;
                                Console.WriteLine("♣ = Trebol:\t\tDuplica la apuesta.");
                                Console.ForegroundColor = ConsoleColor.Cyan;
                                Console.WriteLine("♦ = Diamante:\t\tSi salen 4 se obtiene 1000% de la apuesta, de lo contrario no tendra ningun valor.");
                                Console.ForegroundColor = ConsoleColor.Yellow;
                                Console.WriteLine("☺ = Happy Face:\t\tSe obtiene el 100% de la apuesta por cada icono.");
                                Console.ForegroundColor = ConsoleColor.DarkYellow;
                                Console.WriteLine("* = Sol:\t\tSe obtiene el 25% de la apuesta por cada icono.");
                                Console.ForegroundColor = ConsoleColor.Gray;
                                Console.WriteLine("▲ = Casa:\t\tNo tiene ningun valor en la apuesta.");
                                Console.ForegroundColor = ConsoleColor.DarkBlue;
                                Console.WriteLine("§ = Bomba:\t\tSe perdera toda la apuesta.");
                                Console.ForegroundColor = ConsoleColor.White;
                                Console.WriteLine("\n- PROBABILIDADES -");
                                Console.WriteLine("De obtener el 1000% de la apuesta:\t" + probabilidad + "%");
                                Console.WriteLine("De duplicar la apuesta:\t\t\t" + probabilidad2 + "%");
                                Console.WriteLine("De obtener de regreso la apuesta:\t" + probabilidad3 + "%");
                                Console.WriteLine("De perder la mitad de la apuesta:\t" + probabilidad4 + "%");
                                Console.WriteLine("De perder todo de la apuesta:\t\t" + probabilidad5 + "%");

                                double gananciaAcumulada = 0;
                                bool seguir = true;

                                do
                                {
                                    int[] figuras = new int[4];
                                    string[] figurasstring = new string[4];



                                    for (int i = 0; i < figuras.Length; i++)
                                    {
                                        figuras[i] = r.Next(1, 7);

                                        if (figuras[i] == 1)
                                        {
                                            figurasstring[i] = "♣";
                                        }
                                        else if (figuras[i] == 2)
                                        {
                                            figurasstring[i] = "♦";
                                        }
                                        else if (figuras[i] == 3)
                                        {
                                            figurasstring[i] = "☺";
                                        }
                                        else if (figuras[i] == 4)
                                        {
                                            figurasstring[i] = "*";
                                        }
                                        else if (figuras[i] == 5)
                                        {
                                            figurasstring[i] = "▲";
                                        }
                                        else if (figuras[i] == 6)
                                        {
                                            figurasstring[i] = "§";
                                        }
                                    }

                                    Console.ForegroundColor = ConsoleColor.White;
                                    Console.WriteLine("\n- TÚ JUEGO -\n");
                                    Console.ForegroundColor = ConsoleColor.DarkMagenta;
                                    Console.Write("| ");

                                    for (int i = 0; i < figuras.Length; i++)
                                    {
                                        Console.Write(figurasstring[i] + " | ");
                                    }

                                    int cantTrebol = 0, cantDiamante = 0, cantHappy = 0, cantSol = 0, cantBomb = 0;

                                    for (int i = 0; i < 4; i++)
                                    {
                                        if (figuras[i] == 1)
                                        {
                                            cantTrebol++;
                                        }
                                        else if (figuras[i] == 2)
                                        {
                                            cantDiamante++;
                                        }
                                        else if (figuras[i] == 3)
                                        {
                                            cantHappy++;
                                        }
                                        else if (figuras[i] == 4)
                                        {
                                            cantSol++;
                                        }
                                        else if (figuras[i] == 6)
                                        {
                                            cantBomb++;
                                        }
                                    }

                                    //TREBOL
                                    double gananciaT = 0, gananciaD = 0, gananciaH = 0, gananciaS = 0;
                                    if (cantTrebol == 4)
                                    {
                                        gananciaT = apuesta * 8;
                                    }
                                    else if (cantTrebol > 0 && cantTrebol < 4)
                                    {
                                        gananciaT = apuesta * Math.Pow(2, cantTrebol);
                                    }

                                    //DIAMANTE
                                    if (cantDiamante == 4)
                                    {
                                        gananciaD = apuesta * 10;
                                    }

                                    //HAPPY
                                    if (cantHappy == 1)
                                    {
                                        gananciaD = apuesta * 1;
                                    }
                                    else if (cantHappy == 2)
                                    {
                                        gananciaH = apuesta * 2;
                                    }
                                    else if (cantHappy == 3)
                                    {
                                        gananciaH = apuesta * 3;
                                    }
                                    else if (cantHappy == 4)
                                    {
                                        gananciaH = apuesta * 4;
                                    }

                                    //SOL
                                    if (cantSol == 1)
                                    {
                                        gananciaS = apuesta * 0.25;
                                    }
                                    else if (cantSol == 2)
                                    {
                                        gananciaS = apuesta * 0.50;
                                    }
                                    else if (cantSol == 3)
                                    {
                                        gananciaS = apuesta * 0.75;
                                    }
                                    else if (cantSol == 4)
                                    {
                                        gananciaS = apuesta * 1;
                                    }

                                    //BOMBA
                                    if (cantBomb > 0)
                                    {
                                        gananciaT = 0;
                                        gananciaS = 0;
                                        gananciaH = 0;
                                        gananciaD = 0;
                                        Console.ForegroundColor = ConsoleColor.Red;
                                        Console.WriteLine("\n\n¡Oh no! Lo pierdes todo :(");
                                        Console.ForegroundColor = ConsoleColor.White;
                                    }

                                    double ganancias1 = gananciaD + gananciaH + gananciaS + gananciaT;
                                    Console.ForegroundColor = ConsoleColor.White;
                                    Console.WriteLine("\n\nUsted apostó: Q" + apuesta);
                                    Console.WriteLine("Ganancias obtenidas: Q{0}", ganancias1);
                                    gananciaAcumulada += ganancias1;

                                    if (ganancias1 >= 0)
                                    {
                                        Console.ForegroundColor = ConsoleColor.Green;
                                        Console.WriteLine("\n¿Desea apostar nuevamente sus ganancias? s = si, n = no");
                                        Console.Write("->");
                                        char ap = Convert.ToChar(Console.ReadLine());

                                        if (ap == 's')
                                        {
                                            apuesta = gananciaAcumulada;
                                            gananciaAcumulada = 0;
                                        }
                                        else if (ap == 'n')
                                        {
                                            seguir = false;
                                            Console.Clear();
                                            Console.ForegroundColor = ConsoleColor.White;
                                            Console.WriteLine("¡GRACIAS POR JUGAR! :D\n");
                                            Console.WriteLine("Nombre del jugador: " + nombre + " " + apellido);
                                            Console.WriteLine("DPI del jugador: " + dpi);
                                            Console.WriteLine("Nacionalidad del jugador: " + nacionalidad);
                                            Console.WriteLine("Edad del jugador: " + edad);
                                            Console.WriteLine("\nApostaste: Q" + apuesta);
                                            Console.WriteLine("Tus ganancias acumuladas son: Q" + gananciaAcumulada);
                                            double impuesto = gananciaAcumulada * 0.4;
                                            double total = gananciaAcumulada - impuesto;
                                            Console.WriteLine("Sus ganancias acumuladas después de aplicar un descuento del 40% resultaron en: Q" + total);

                                            if (gananciaAcumulada > 0)
                                            {
                                                Console.WriteLine("\n");
                                                Console.ForegroundColor = ConsoleColor.Green;
                                                Console.WriteLine("FELICIDADES!!");
                                                Console.ForegroundColor = ConsoleColor.Yellow;
                                                Console.WriteLine("FELICIDADES!!");
                                                Console.ForegroundColor = ConsoleColor.Blue;
                                                Console.WriteLine("FELICIDADES!!");
                                                Console.ForegroundColor = ConsoleColor.Magenta;
                                                Console.WriteLine("FELICIDADES!!");
                                            }
                                            else
                                            {
                                                Console.WriteLine("\n");
                                                Console.ForegroundColor = ConsoleColor.Green;
                                                Console.WriteLine("¡MÁS SUERTE A LA PROXIMA!");
                                                Console.ForegroundColor = ConsoleColor.Yellow;
                                                Console.WriteLine("¡MÁS SUERTE A LA PROXIMA!");
                                                Console.ForegroundColor = ConsoleColor.Blue;
                                                Console.WriteLine("¡MÁS SUERTE A LA PROXIMA!");
                                                Console.ForegroundColor = ConsoleColor.Magenta;
                                                Console.WriteLine("¡MÁS SUERTE A LA PROXIMA!");
                                            }
                                        }
                                    }
                                    else
                                    {
                                        seguir = false;
                                        Console.WriteLine("\nVuelva pronto!");
                                    }
                                }
                                while (seguir != false);

                                menu = "2";
                                Console.ReadKey();
                                break;

                            case "n" or "N":
                                menu = "2";
                                Console.ReadKey();
                                break;
                        }
                    }
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Gracias por participar <3");
                }
            }
            else
            {
                Console.WriteLine("ERROR: No tienes la edad suficiente para realizar una apuesta :(");
            }
        }
        catch
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("¡¡¡ERROR: Ingresa datos validos!!!");
            Console.ForegroundColor = ConsoleColor.White;
        }
    }
}